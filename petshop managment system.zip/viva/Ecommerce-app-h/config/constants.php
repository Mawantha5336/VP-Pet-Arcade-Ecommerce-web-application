<?php

define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', 'MawaNtha5@5336');
define('DATABASE_NAME', 'ecom');

define('CURRENCY', 'Rs');



?>